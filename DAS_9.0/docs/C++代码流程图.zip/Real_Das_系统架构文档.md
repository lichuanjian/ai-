# Real_Das 系统架构文档

## 1. 系统概述

Real_Das 是一个基于Qt的实时数据采集与处理系统，主要用于光纤传感数据的采集、处理、显示和存储。系统采用多线程架构，通过信号-槽机制实现模块间的异步通信。

### 核心技术栈
- **框架**: Qt6 (C++)
- **图表库**: QCustomPlot
- **FFT库**: FFTW3
- **滤波库**: IIR (Chebyshev I型高通滤波器)
- **硬件接口**: PCIe DMA (XDMA)

---

## 2. 模块功能说明（按CPP文件）

### 2.1 数据采集层

| 文件 | 功能描述 | 角色 |
|------|----------|------|
| **pcie_fun.c** | PCIe硬件接口层，提供DMA数据传输功能。包含设备初始化、内存分配、数据读写控制等功能。 | 硬件抽象层 |
| **receive_data.cpp** | 数据接收器，定时从PCIe读取原始数据，解码为浮点相位数据，并通过信号发送给下游。支持双缓冲（mode18/mode28）。 | 数据生产者 |

### 2.2 数据处理层

| 文件 | 功能描述 | 角色 |
|------|----------|------|
| **rebuild_data.cpp** | 数据重构器，执行差分计算和矩阵转置。将原始相位数据转换为差分数据，支持按抽取因子裁剪数据。 | 数据处理器 |
| **unwrap.cpp** | 相位解缠绕器，消除相位数据中的2π跳变，保证相位连续性。采用行级记忆机制，每行独立维护上一次处理的最后值。 | 数据处理器 |
| **Filter.cpp** | 滤波处理器，实现基于Chebyshev I型8阶高通滤波器的并行滤波。支持多线程并行处理，每行使用独立滤波器。 | 数据处理器 |
| **rms_calculate.cpp** | RMS计算器，计算数据的均方根值。按组计算方差，支持批量数据处理。 | 数据处理器 |
| **fft_calculate.cpp** | FFT计算器，使用FFTW3库执行快速傅里叶变换，将时域数据转换为频域数据。 | 数据处理器 |

### 2.3 数据存储层

| 文件 | 功能描述 | 角色 |
|------|----------|------|
| **sava_data.cpp** | 数据保存器，支持单点保存和全部保存两种模式。自动管理磁盘空间，支持文件分割（最大2GB）。 | 数据消费者 |

### 2.4 音频输出层

| 文件 | 功能描述 | 角色 |
|------|----------|------|
| **audio.cpp** | 音频处理器，将滤波后的数据通过QAudioSink输出到音频设备。支持动态采样率调整。 | 数据消费者 |

### 2.5 UI显示层

| 文件 | 功能描述 | 角色 |
|------|----------|------|
| **mainwindow.cpp** | 主窗口控制器，整合UI控件、参数管理和信号槽连接。处理用户交互事件。 | UI控制器 |
| **mainwindowdata.cpp** | 数据渲染器，接收处理后的数据并渲染到各个图表。支持音频波形图、RMS瀑布图、FFT瀑布图。 | 数据消费者 |
| **mainwindowplot.cpp** | 图表初始化器，负责初始化各类图表的样式、坐标轴、颜色映射等。 | UI辅助 |
| **qcustomplot.cpp** | 第三方图表库，提供高性能的实时数据可视化功能。 | 图表引擎 |

### 2.6 工具层

| 文件 | 功能描述 | 角色 |
|------|----------|------|
| **parametermanager.cpp** | 参数管理器（单例模式），提供线程安全的全局参数存储和变更通知机制。 | 配置中心 |
| **mainwindowutils.cpp** | 主窗口工具函数，提供单位转换、距离计算等辅助功能。 | 工具函数 |
| **toolutils.cpp** | 通用工具函数，提供文件操作、数据处理等辅助功能。 | 工具函数 |

---

## 3. 数据流向图

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                                    数据流向总览                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘

【硬件层】
     │
     ▼
┌─────────────┐     ┌─────────────┐
│  PCIe设备   │────▶│ pcie_fun.c  │
└─────────────┘     └──────┬──────┘
                           │
                           ▼
【数据采集层】              
                    ┌─────────────┐
                    │receive_data │◀── 定时器触发 (12ms)
                    └──────┬──────┘
                           │ Raw_data(float* data, rows, cols, freq, extractCount, ...)
                           ▼
【数据处理层 - 流水线】
                    ┌─────────────┐
                    │ rebuild_data│ 差分计算 + 矩阵转置
                    └──────┬──────┘
                           │ widget_my_array_Signal
                           ▼
                    ┌─────────────┐
                    │   unwrap    │ 相位解缠绕 (消除2π跳变)
                    └──────┬──────┘
                           │ Unwrap_Data_Signal
                           ▼
                    ┌─────────────┐
                    │    Filter   │ 并行高通滤波 (Chebyshev I型8阶)
                    └──────┬──────┘
                           │
           ┌───────────────┼───────────────┐
           │               │               │
           ▼               ▼               ▼
    ┌────────────┐  ┌────────────┐  ┌────────────┐
    │    FFT     │  │    RMS     │  │   Audio    │
    │  fft_calc  │  │  rms_calc  │  │   audio    │
    └─────┬──────┘  └─────┬──────┘  └────────────┘
          │               │
          ▼               ▼
【UI显示层】
    ┌────────────┐  ┌────────────┐
    │ FFT瀑布图  │  │ RMS瀑布图  │
    │  (widget_3)│  │  (widget_2)│
    └────────────┘  └────────────┘
                           ▲
                           │ (应变模式)
                    ┌────────────┐
                    │  应变计算   │
                    └────────────┘

【数据存储层 - 并行分支】
                    ┌─────────────┐
                    │  sava_data  │◀── Unwrap_Data_SaveSignal
                    └─────────────┘     (单点保存 / 全部保存)
```

---

## 4. 详细信号-槽连接关系

### 4.1 主数据处理链

```
┌────────────────────────────────────────────────────────────────────────┐
│                          主数据处理流水线                               │
└────────────────────────────────────────────────────────────────────────┘

receive_data::Raw_data ─────────────────────────────────────────────────▶
    (float* data, size_t mode, int rows, int cols, int freq, 
     int extractCount, int start, int end, int diffDist)
                                    │
                                    ▼
rebuild_data::Receive_raw_data ─────────────────────────────────────────▶
                                    │
                                    ▼
rebuild_data::widget_my_array_Signal ───────────────────────────────────▶
    (float* array, int rows, int cols, int freq, extractCount, ...)
                                    │
                                    ▼
unwrap::Receive_rebuild_data ───────────────────────────────────────────▶
                                    │
                                    ▼
unwrap::Unwrap_Data_Signal ─────────────────────────────────────────────▶
    (float* array, int rows, int cols, int freq, int extractCount)
                                    │
                                    ▼
Filter::array_handleSignal ─────────────────────────────────────────────▶
                                    │
                                    ├──▶ Filter::array_tongguolvboSignal ──▶ FFT_Calculate::FFT_handleSignal
                                    │                                          │
                                    │                                          ▼
                                    │                              fft_calculator::FFT_OK_Signal ──▶ 
                                    │                              MainWindow::onReceiveFFTData
                                    │
                                    ├──▶ Filter::Filter_my_array_Signal ───▶ rms_calculate::array_handleSignal
                                    │                                          │
                                    │                                          ▼
                                    │                              rms_calculate::sendDataToReceiver ──▶
                                    │                              MainWindow::onReceiveRMSData
                                    │
                                    └──▶ Filter::multiAudioRowsSignal ─────▶ MainWindow::onReceiveMultiAudioData
```

### 4.2 数据保存分支

```
┌────────────────────────────────────────────────────────────────────────┐
│                          数据保存分支                                   │
└────────────────────────────────────────────────────────────────────────┘

unwrap::Unwrap_Data_SaveSignal ─────────────────────────────────────────▶
    (float* array, int rows, int cols, int freq, extractCount, 
     int start, int end, int diffDist)
                                    │
                                    ▼
sava_data::Preserve_rebuild_data ───────────────────────────────────────▶
                                    │
                                    ├──▶ 单点保存 (m_saveSingleFlag)
                                    │      - 保存指定行的数据
                                    │      - 文件大小限制2GB，自动分割
                                    │
                                    └──▶ 全部保存 (m_saveAllFlag)
                                           - 保存整个数组数据
                                           - 文件大小限制2GB，自动分割
```

---

## 5. 生产者-消费者关系

### 5.1 生产者-消费者矩阵

| 生产者 | 消费者 | 数据类型 | 信号名称 |
|--------|--------|----------|----------|
| **receive_data** | rebuild_data | float* (原始相位数据) | `Raw_data` |
| **rebuild_data** | unwrap | float* (差分数据) | `widget_my_array_Signal` |
| **unwrap** | Filter | float* (解缠绕数据) | `Unwrap_Data_Signal` |
| **unwrap** | sava_data | float* (解缠绕数据) | `Unwrap_Data_SaveSignal` |
| **Filter** | FFT_Calculate | QVector<float> (滤波后数据) | `array_tongguolvboSignal` |
| **Filter** | rms_calculate | float* (滤波后数据) | `Filter_my_array_Signal` |
| **Filter** | MainWindow | QList<QVector<float>> (多路音频) | `multiAudioRowsSignal` |
| **FFT_Calculate** | MainWindow | QVector<float> (FFT结果) | `FFT_OK_Signal` |
| **rms_calculate** | MainWindow | QList<QVector<float>> (RMS数据) | `sendDataToReceiver` |

### 5.2 线程分配

```
┌────────────────────────────────────────────────────────────────────────┐
│                          线程分配图                                     │
└────────────────────────────────────────────────────────────────────────┘

主线程 (UI线程)
├── MainWindow (UI控制器)
├── MainWindowData (数据渲染)
├── MainWindowPlot (图表初始化)
└── ParameterManager (参数管理)

子线程1 (RMS计算)
└── rms_calculate

子线程2 (数据保存)
└── sava_data (Low Priority)

子线程3 (滤波处理)
└── Filter (Low Priority)

子线程4 (音频输出)
└── Audio (High Priority)

子线程5 (FFT计算)
└── FFT_Calculate (High Priority)

子线程6 (数据重构)
└── rebuild_data

子线程7 (相位解缠绕)
└── unwrap

子线程8 (数据接收)
└── receive_data
```

---

## 6. 核心数据结构

### 6.1 数据矩阵布局

```
原始数据布局 (receive_data):
┌─────────────────────────────────────────────────────────────┐
│  phase_buf[col * kMaxRows + row]                            │
│  - 列主序存储                                                │
│  - kMaxRows = 1024 * 24 = 24576                             │
│  - kMaxCols = 5000                                          │
└─────────────────────────────────────────────────────────────┘

重构后数据布局 (rebuild_data):
┌─────────────────────────────────────────────────────────────┐
│  output_buffer[row][col]                                    │
│  - 行主序存储                                                │
│  - 差分计算: dst[row][col] = src[col][baseRow+diff] - src[col][baseRow] │
│  - 支持抽取因子 (extractCount) 裁剪                          │
└─────────────────────────────────────────────────────────────┘
```

### 6.2 参数配置

| 参数名 | 默认值 | 说明 |
|--------|--------|------|
| `pulse_frequency` | 10000 | 脉冲频率 (Hz) |
| `extract_count` | 8 | 抽取因子 |
| `differential_distance` | 8 | 差分距离 |
| `start_save` | 0 | 保存起始通道 |
| `end_save` | 0 | 保存结束通道 |
| `monitorPosition` | 200 | 音频监听位置 |
| `singleSaveRow` | 200 | 单点保存行号 |

---

## 7. 性能监控点

系统在各处理阶段都记录了处理时间，通过信号发送到主窗口显示：

| 监控点 | 信号 | 发送者 |
|--------|------|--------|
| PCIe读取时间 | `pcieProcessingTime` | receive_data |
| 数据重构时间 | `totalProcessingTime` | rebuild_data |
| 相位解缠绕时间 | `preserveProcessingTime` | unwrap |
| 滤波处理时间 | `processingTimeMeasured` | Filter |
| RMS计算时间 | `rmsProcessingTime` | rms_calculate |
| FFT计算时间 | `fftProcessingTime` | FFT_Calculate |

---

## 8. 文件依赖关系

```
main.cpp
├── mainwindow.h/cpp
│   ├── MainWindowPlot.h/cpp
│   ├── MainWindowData.h/cpp
│   └── MainWindowUtils.h/cpp
├── receive_data.h/cpp
├── rebuild_data.h/cpp
├── unwrap.h/cpp
├── Filter.h/cpp
│   └── Iir.h (第三方)
├── rms_calculate.h/cpp
├── fft_calculate.h/cpp
│   └── fftw3.h (第三方)
├── audio.h/cpp
├── sava_data.h/cpp
├── parametermanager.h/cpp
├── pcie_fun.c/h
│   └── xdma_public.h
├── qcustomplot.h/cpp (第三方)
└── toolutils.h/cpp
```

---

## 9. 关键设计模式

### 9.1 单例模式
- **ParameterManager**: 全局参数管理中心，确保配置一致性

### 9.2 观察者模式
- **信号-槽机制**: 模块间通过Qt信号-槽进行松耦合通信
- **参数变更通知**: ParameterManager通过`parameterChanged`信号通知所有监听者

### 9.3 生产者-消费者模式
- **数据流水线**: receive_data → rebuild_data → unwrap → Filter → [FFT/RMS/Audio]
- **双缓冲机制**: mode18/mode28交替使用，避免数据覆盖

### 9.4 线程池模式
- **并行滤波**: Filter模块使用QtConcurrent实现多线程并行处理

---

## 10. 数据流详细说明

### 10.1 数据生产者

#### receive_data (数据接收器)
- **角色**: 数据生产者
- **功能**: 从PCIe设备读取原始数据，解码为浮点相位数据
- **触发方式**: QTimer定时触发（12ms周期）
- **输出信号**: `Raw_data(float* data, size_t mode, int rows, int cols, int frequency, int extractCount, int start, int end, int differentialDistance)`
- **双缓冲机制**: 使用phase_buf和phase_buf_2交替存储，支持mode18和mode28两种模式

### 10.2 数据处理器

#### rebuild_data (数据重构器)
- **角色**: 数据处理器
- **输入**: receive_data::Raw_data
- **功能**: 
  - 差分计算: dst[row][col] = src[col][baseRow+diff] - src[col][baseRow]
  - 矩阵转置: 列主序 → 行主序
  - 按抽取因子裁剪数据
- **输出信号**: `widget_my_array_Signal(float* array, int rows, int cols, int frequency, int extractCount, int start, int end, int differentialDistance)`

#### unwrap (相位解缠绕器)
- **角色**: 数据处理器
- **输入**: rebuild_data::widget_my_array_Signal
- **功能**: 消除相位数据中的2π跳变
  - 使用行级记忆机制，每行独立维护上一次处理的最后值
  - 公式: `n = floor((diff + PI) / TWO_PI)`
- **输出信号**: 
  - `Unwrap_Data_Signal`: 发送给Filter进行后续处理
  - `Unwrap_Data_SaveSignal`: 发送给sava_data进行保存

#### Filter (滤波处理器)
- **角色**: 数据处理器
- **输入**: unwrap::Unwrap_Data_Signal
- **功能**: 
  - 8阶Chebyshev I型高通滤波器
  - 截止频率: 1Hz
  - 并行处理: 使用QtConcurrent实现多线程
  - 每行使用独立滤波器，避免状态干扰
- **输出信号**:
  - `array_tongguolvboSignal`: 发送给FFT_Calculate
  - `Filter_my_array_Signal`: 发送给rms_calculate
  - `multiAudioRowsSignal`: 发送给MainWindow显示音频波形

#### rms_calculate (RMS计算器)
- **角色**: 数据处理器
- **输入**: Filter::Filter_my_array_Signal
- **功能**: 计算数据的均方根值
  - 按组计算方差（默认每组1000个点）
  - 公式: `RMS = sqrt(mean_squared)`
- **输出信号**: `sendDataToReceiver(QList<QVector<float>> data, int rows, int cols, int frequency, int extractCount)`

#### fft_calculate (FFT计算器)
- **角色**: 数据处理器
- **输入**: Filter::array_tongguolvboSignal
- **功能**: 使用FFTW3库执行快速傅里叶变换
- **输出信号**: `FFT_OK_Signal(QVector<float> fft_Vector, int length, int frequency)`

### 10.3 数据消费者

#### sava_data (数据保存器)
- **角色**: 数据消费者
- **输入**: unwrap::Unwrap_Data_SaveSignal
- **功能**: 
  - 单点保存: 保存指定行的数据
  - 全部保存: 保存整个数组数据
  - 文件大小限制2GB，自动分割
  - 磁盘空间检查，自动提醒

#### audio (音频处理器)
- **角色**: 数据消费者
- **输入**: Filter::array_tongguolvboSignal (通过MainWindow转发)
- **功能**: 将滤波后的数据通过QAudioSink输出到音频设备

#### MainWindowData (数据渲染器)
- **角色**: 数据消费者
- **输入**: 
  - MainWindow::onReceiveRMSData → onReceiveRMSData/onReceiveStrainData
  - MainWindow::onReceiveFFTData → onReceiveFFTData
  - MainWindow::onReceiveMultiAudioData → onReceiveMultiAudioData
- **功能**: 将数据渲染到各个图表（音频波形图、RMS瀑布图、FFT瀑布图）

---

## 11. 系统特点

### 11.1 高性能设计
- **多线程并行**: 8个子线程分别处理不同任务
- **双缓冲机制**: 避免数据覆盖，保证数据完整性
- **零拷贝设计**: 尽可能减少数据复制，提高处理效率
- **节流渲染**: 使用QElapsedTimer控制重绘频率，避免UI卡顿

### 11.2 可配置性
- **参数管理器**: 全局统一的参数管理，支持动态调整
- **滤波开关**: 支持启用/禁用滤波功能
- **模式切换**: 支持RMS模式和应变模式切换

### 11.3 可靠性
- **磁盘空间检查**: 自动检查磁盘空间，避免写入失败
- **文件分割**: 自动分割大文件（2GB限制）
- **错误处理**: 完善的错误处理和日志记录

---

*文档生成时间: 2026-02-25*
*系统版本: Real_Das v1.0*
